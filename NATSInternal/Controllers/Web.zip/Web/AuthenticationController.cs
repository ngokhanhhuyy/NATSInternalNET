﻿namespace NATSInternal.Controllers.Web;

[Route("/Authentication")]
[Authorize]
public class AuthenticationController : Controller
{
    private IAuthenticationService _authenticationService;
    private IValidator<SignInRequestDto> _signInValidator;

    public AuthenticationController(
            IAuthenticationService authenticationService,
            IValidator<SignInRequestDto> signInValidator)
    {
        _authenticationService = authenticationService;
        _signInValidator = signInValidator;
    }

    [AllowAnonymous]
    [HttpGet("SignIn")]
    public IActionResult SignIn()
    {
        if (User.Identity.IsAuthenticated)
        {
            return RedirectToAction("Index", "Home");
        }
        return View();
    }

    [AllowAnonymous]
    [HttpPost("SignIn")]
    public async Task<IActionResult> SignIn(SignInModel model, [FromQuery] string returnUrl = null)
    {
        if (User.Identity.IsAuthenticated)
        {
            return RedirectToAction("Index", "Home");
        }

        SignInRequestDto requestDto = new SignInRequestDto
        {
            UserName = model.UserName,
            Password = model.Password
        };
        ValidationResult validationResult;
        validationResult = _signInValidator.Validate(requestDto.TransformValues());
        if (!validationResult.IsValid)
        {
            ModelState.AddModelErrorsFromValidationErrors(validationResult.Errors);
            return View(model);
        }

        try
        {
            await _authenticationService.SignInAsync(requestDto);
            if (returnUrl != null)
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }
        catch (ResourceNotFoundException exception)
        {
            ModelState.AddModelErrorsFromServiceException(exception);
            return View(model);
        }
        catch (OperationException exception)
        {
            ModelState.AddModelErrorsFromServiceException(exception);
            return View(model);
        }
    }

    [Authorize]
    [HttpGet("SignOut")]
    public new async Task<IActionResult> SignOut()
    {
        await _authenticationService.SignOutAsync();
        return RedirectToAction("SignIn", "Authentication");
    }
}
