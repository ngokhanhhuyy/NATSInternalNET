﻿namespace NATSInternal.Controllers.Web;

[Route("/")]
[Authorize]
public class HomeController : Controller
{
    [HttpGet]
    public IActionResult Index()
    {
        return View("/Views/Dashboard/Dashboard.cshtml");
    }
}
