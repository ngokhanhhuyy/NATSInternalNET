namespace NATSInternal.Controllers;

[Route("/User")]
[Authorize]
public class UserController : Controller
{
    private IUserService _userService;
    private IRoleService _roleService;
    private IValidator<UserListRequestDto> _listValidator;

    public UserController(
            IUserService userService,
            IRoleService roleService,
            IValidator<UserListRequestDto> listValidator)
    {
        _userService = userService;
        _roleService = roleService;
        _listValidator = listValidator;
    }

    [HttpGet("List")]
    public async Task<IActionResult> UserList([FromQuery] UserListModel model = null)
    {
        // Initialize a default model if the model argument is null.
        model ??= new UserListModel();

        // Map model to request dto.
        UserListRequestDto requestDto = model.ToRequestDto();

        // Validate data from request.
        ValidationResult validationResult;
        validationResult = _listValidator.Validate(requestDto.TransformValues());
        if (!validationResult.IsValid)
        {
            return Redirect("/Error");
        }

        // Fetch user list.
        UserListResponseDto responseDto = await _userService.GetListAsync(requestDto);

        // Fetch role options.
        RoleListResponseDto roleListResponseDto;
        roleListResponseDto = await _roleService.GetListAsync();

        model.MapFromResponseDtos(responseDto, roleListResponseDto);
        return View("/Views/User/UserList/UserList.cshtml", model);
    }
}