namespace NATSInternal.Services.Dtos;

public class CustomerCreateResponseDto
{
    public int Id { get; set; }
}