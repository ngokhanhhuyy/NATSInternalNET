﻿namespace NATSInternal.Services.Dtos;

public class BrandBasicResponseDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}
