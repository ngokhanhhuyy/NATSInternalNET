﻿namespace NATSInternal.Services.Dtos;

public class ProductListRequestDto : IRequestDto<ProductListRequestDto>
{
    public ProductCategoryRequestDto Category { get; set; }

    public ProductListRequestDto TransformValues()
    {
        Category.TransformValues();
        return this;
    }
}
