﻿namespace NATSInternal.Services.Dtos;

public class ProductListResponseDto
{
    public List<ProductBasicResponseDto> Items { get; set; }
}
