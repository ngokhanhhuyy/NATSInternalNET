﻿namespace NATSInternal.Services.Dtos;

public class UserCreateResponseDto
{
    public int Id { get; set; }
}