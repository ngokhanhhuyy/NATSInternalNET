﻿namespace NATSInternal.Services.Dtos;

public class RoleListResponseDto {
    public List<RoleBasicResponseDto> Items { get; init; }
}
