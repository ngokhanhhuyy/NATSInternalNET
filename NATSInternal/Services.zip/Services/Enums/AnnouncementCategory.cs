﻿namespace NATSInternal.Services.Enums;

public enum AnnouncementCategory
{
    Announcement,
    News,
    Warning
}