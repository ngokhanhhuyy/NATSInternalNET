﻿namespace NATSInternal.Services.Enums;

public enum PatchOperation
{
    Create,
    Update,
    Replace,
    Delete
}
