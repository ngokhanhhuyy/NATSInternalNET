namespace NATSInternal.Services.Enums;

public enum TreatmentPhotoType
{
    Before,
    After
}