﻿namespace NATSInternal.Services.Exceptions;

public class AuthorizationException : Exception
{
}
