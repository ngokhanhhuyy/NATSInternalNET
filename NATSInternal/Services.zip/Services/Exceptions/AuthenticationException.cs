﻿namespace NATSInternal.Services.Exceptions;

public class AuthenticationException(string message) : Exception(message)
{
}
