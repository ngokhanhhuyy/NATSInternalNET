namespace NATSInternal.Services.Entities;

[Table("supply_items")]
public class SupplyItem
{
    [Column("id")]
    [Key]
    public int Id { get; set; }

    [Column("amount")]
    [Required]
    public long Amount { get; set; }

    [Column("vat_factor")]
    [Required]
    public decimal VatFactor { get; set; } = 0.1M;

    [Column("supplied_quantities")]
    [Required]
    public int SuppliedQuantity { get; set; } = 1;

    // Foreign keys
    [Column("supply_id")]
    [Required]
    public int SupplyId { get; set; }

    [Column("product_id")]
    [Required]
    public int ProductId { get; set; }

    // Concurrency operation tracking field
    [Timestamp]
    public byte[] RowVersion { get; set; }

    // Relationships
    public virtual Supply Supply { get; set; }
    public virtual Product Product { get; set; }
    public virtual List<OrderItem> OrderItems { get; set; }
}