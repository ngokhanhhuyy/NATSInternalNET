namespace NATSInternal.Services.Entities;

[Table("supplies")]
public class Supply
{
    [Column("id")]
    [Key]
    public int Id { get; set; }

    [Column("supplied_datetime")]
    [Required]
    public DateTime SuppliedDateTime { get; set; }

    [Column("shipment_fee")]
    [Required]
    public long ShipmentFee { get; set; } = 0;

    [Column("paid_amount")]
    [Required]
    public long PaidAmount { get; set; } = 0;

    [Column("note")]
    [StringLength(255)]
    public string Note { get; set; }

    // Foreign keys
    [Column("user_id")]
    [Required]
    public int UserId { get; set; }

    // Concurrency operation tracking field
    [Timestamp]
    public byte[] RowVersion { get; set; }

    // Relationships
    public virtual User User { get; set; }
    public virtual List<SupplyItem> Items { get; set; }
    public virtual List<SupplyPhoto> Photos { get; set; }
}