﻿namespace NATSInternal.Services.Constants;

public static class RoleConstants
{
    public const string Developer = "Developer";
    public const string Manager = "Manager";
    public const string Accountant = "Accountant";
    public const string Staff = "Staff";
}
