﻿namespace NATSInternal.Services.Constants;

public static class PermissionConstants
{
    // Permissions to interact with users.
    public const string CreateUser = "CreateUser";
    public const string GetOtherUserPersonalInformation = "GetOtherUserPersonalInformation";
    public const string GetOtherUserUserInformation = "GetOtherUserUserInformation";
    public const string EditSelfPersonalInformation = "EditSelfPersonalInformation";
    public const string EditSelfUserInformation = "EditSelfUserInformation";
    public const string EditOtherUserPersonalInformation = "EditOtherUserPersonalInformation";
    public const string EditOtherUserUserInformation = "EditOtherUserUserInformation";
    public const string ResetOtherUserPassword = "ResetOtherUserPassword";
    public const string DeleteUser = "DeleteUser";
    public const string RestoreUser = "RestoreUser";

    // Permissions to interact with customers.
    public const string GetCustomerDetail = "GetCustomerDetail";
    public const string CreateCustomer = "CreateCustomer";
    public const string EditCustomer = "EditCustomer";
    public const string DeleteCustomer = "DeleteCustomer";

    // Permissions to interact with brands.
    public const string CreateBrand = "CreateBrand";
    public const string UpdateBrand = "UpdateBrand";
    public const string DeleteBrand = "DeleteBrand";

    // Permissions to interact with products
    public const string CreateProduct = "CreateProduct";
    public const string UpdateProduct = "UpdateProduct";
    public const string DeleteProduct = "DeleteProduct";

    // Permissions to interact with product categories
    public const string CreateProductCategory = "CreateProductCategory";
    public const string UpdateProductCategory = "UpdateProductCategory";
    public const string DeleteProductCategory = "DeleteProductCategory";

}
