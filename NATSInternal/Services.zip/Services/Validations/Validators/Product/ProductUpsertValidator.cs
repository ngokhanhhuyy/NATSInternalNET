﻿namespace NATSInternal.Services.Validations.Validators.Product;

public class ProductUpsertValidator : Validator<ProductUpsertRequestDto>
{
    public ProductUpsertValidator()
    {
        RuleFor(dto => dto.Name)
            .NotEmpty()
            .MaximumLength(50)
            .WithName(dto => DisplayNames.Get(nameof(dto.Name)));
        RuleFor(dto => dto.Description)
            .MaximumLength(1000)
            .WithName(dto => DisplayNames.Get(nameof(dto.Description)));
        RuleFor(dto => dto.Unit)
            .NotEmpty()
            .MaximumLength(12)
            .WithName(dto => DisplayNames.Get(nameof(dto.Unit)));
        RuleFor(dto => dto.Price)
            .GreaterThanOrEqualTo(0)
            .WithName(dto => DisplayNames.Get(nameof(dto.Price)));
        RuleFor(dto => dto.VatFactor)
            .GreaterThanOrEqualTo(0.0m)
            .WithName(dto => DisplayNames.Get(nameof(dto.VatFactor)));
        RuleFor(dto => dto.ThumbnailFile)
            .Must(IsValidImage)
            .WithName(dto => DisplayNames.Get(nameof(dto.ThumbnailFile)));
    }
}
